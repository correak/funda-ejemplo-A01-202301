﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APDAYC_Ejercicio1_EP202302.Reportes
{
    public class peliSegunGenero
    {
        public string Nombre { get; set; }
        public string Genero { get; set; }
       
    }

    public class peliMastaquilleraXaño
    {
        public string Nombre { get; set; }
        public string AñoEstreno { get; set; }
    }

}
