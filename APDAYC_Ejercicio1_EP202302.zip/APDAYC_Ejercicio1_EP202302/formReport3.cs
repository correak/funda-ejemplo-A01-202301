﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APDAYC_Ejercicio1_EP202302
{
    public partial class formReport3 : Form
    {
        public formReport3()
        {
            InitializeComponent();
        }
    }
}
