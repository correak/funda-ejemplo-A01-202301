﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APDAYC_Ejercicio1_EP202302.Entities
{
    internal class Pelicula
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Genero { get; set; }
        public string Estado { get; set; }
        public string Duracion { get; set; }
        public string TaquillaG { get; set; }
        public string AnioEstreno { get; set; }
       
    }
}
